from fastapi import FastAPI
from prometheus_fastapi_instrumentator import Instrumentator
from fastapi.responses import FileResponse, HTMLResponse
from .routers import receivables

api = FastAPI(title="Receivables Discount API", version="1.0.0")
Instrumentator().instrument(api).expose(api, endpoint="/metrics")

@api.get("/health")
def health():
    return {"status": "ok"}

@api.get("/", response_class=HTMLResponse)
def root():
    return FileResponse("app/web/index.html")

api.include_router(receivables.router, prefix="/receivables", tags=["receivables"])
